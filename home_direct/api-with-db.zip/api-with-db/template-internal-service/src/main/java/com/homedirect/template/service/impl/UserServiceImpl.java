
package com.homedirect.template.service.impl;

import org.springframework.integration.annotation.MessageEndpoint;
import org.springframework.integration.annotation.ServiceActivator;

import com.homedirect.template.model.User;
import com.homedirect.template.repository.UserRepository;
import com.homedirect.template.service.UserService;

/**
 *  Author : duy.bui
 * Oct 27, 2017
 */
@MessageEndpoint
public class UserServiceImpl  extends AbstractServiceImpl<User, String, UserRepository> implements UserService {
  
  @ServiceActivator(inputChannel = "user-registry-channel-4-service")
  public String registryUser(User user) {
    repo.save(user);
    return user.getUsername();
  }
  
}
